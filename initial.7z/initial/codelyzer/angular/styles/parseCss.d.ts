import { CssAst } from './cssAst';
export declare const parseCss: (text: string) => CssAst;
