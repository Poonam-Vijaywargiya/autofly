export declare class PathResolver {
    resolve(path: string, relative: string): string | null;
}
